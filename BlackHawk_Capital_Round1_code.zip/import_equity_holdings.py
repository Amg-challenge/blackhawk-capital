"""Import FactSet holdings and hierarchical sector exports without double counting."""
import json
import re
from pathlib import Path
import pandas as pd
from openpyxl import load_workbook
import uuid

ROOT = Path(__file__).resolve().parent
FOLDER = ROOT/'factset_screening'
ETFS = ['VOO','VTV','IEFA','EEM']
all_equities, residuals, sectors, checks = [], [], [], []

for etf in ETFS:
    holding_file = FOLDER/f'{etf} Holdings.xlsx'
    raw = pd.read_excel(holding_file,header=None)
    assert f'{etf}-US' in str(raw.iloc[0,0])
    header = next(i for i,row in raw.iterrows() if 'Report Date' in row.astype(str).values)
    data = pd.read_excel(holding_file,header=header,dtype={'ID':str,'Ticker':str})
    data = data.rename(columns={data.columns[0]:'Holding name'})
    # Keep Totalenergies; remove only the explicit total-summary row.
    data = data.loc[~data['Holding name'].astype(str).str.match(r'^Total \(Count')].copy()
    data['Weight percent'] = pd.to_numeric(data['EQ %Port'],errors='raise')
    assert abs(data['Weight percent'].sum()-100)<1e-5
    dates = pd.to_datetime(data['Report Date'],format='%m/%d/%Y').dt.strftime('%Y-%m-%d')
    assert dates.nunique()==1
    snapshot = dates.iloc[0]
    equity_mask = data['Ticker'].fillna('').str.match(r'^.+-[A-Z]{2}$')

    sector_file = FOLDER/(f'{etf} Sector.xlsx' if etf=='VOO' else f'{etf} Sectors.xlsx')
    workbook = load_workbook(sector_file,data_only=True)
    sheet = workbook.active
    assert f'{etf}-US' in str(sheet.cell(1,1).value)
    sector_header = next(r for r in range(1,sheet.max_row+1) if sheet.cell(r,1).value=='Sector')
    sector_map, parent = {}, None
    top_total = 0.0
    for r in range(sector_header+2,sheet.max_row+1):
        cell = sheet.cell(r,1)
        name = cell.value
        if not name:
            continue
        indent = cell.alignment.indent
        if indent==0:
            parent = re.sub(r'\s*\(\d+\)$','',str(name)).strip()
            weight = float(sheet.cell(r,2).value)
            sectors.append({'ETF':etf,'Sector':parent,'Weight percent':weight,
                            'Data date':snapshot,'Classification':'FactSet sector taxonomy',
                            'Source':sector_file.name})
            top_total += weight
        elif indent==4:
            key = ' '.join(str(name).split())
            if key in sector_map and sector_map[key]!=parent:
                raise ValueError(f'Ambiguous sector for {key}')
            sector_map[key] = parent
    assert abs(top_total-100)<1e-5, f'{etf}: incomplete top-level sectors'

    equity = data.loc[equity_mask].copy()
    assert not equity['ID'].duplicated().any()
    assert equity['Weight percent'].ge(0).all()
    equity['ETF'] = etf
    equity['Holding identifier'] = equity['ID']
    equity['Sector'] = equity['Holding name'].map(lambda name:sector_map.get(' '.join(str(name).split()),''))
    equity['Country'] = ''  # Not supplied: listing market must not be mislabeled as domicile.
    equity['Data date'] = snapshot
    equity['Source'] = f'FactSet: {holding_file.name}; {sector_file.name}'
    assert equity['Sector'].ne('').all(), f'{etf}: unmatched sector names'
    all_equities.append(equity[['ETF','Holding identifier','Holding name','Weight percent','Sector','Country',
                               'Ticker','Data date','Source']])
    residual = data.loc[~equity_mask,['Holding name','Weight percent','ID','Ticker']].copy()
    residual['ETF'],residual['Data date'] = etf,snapshot
    residuals.append(residual)
    checks.append({'ETF':etf,'Snapshot':snapshot,'Equity securities':len(equity),
                   'Equity weight percent':equity['Weight percent'].sum(),
                   'Signed residual percent':residual['Weight percent'].sum(),
                   'All holdings percent':data['Weight percent'].sum(),
                   'Sector totals percent':top_total,'Unmatched sector names':int(equity['Sector'].eq('').sum())})

pd.concat(all_equities).to_csv(ROOT/'equity_holdings_inputs.csv',index=False)
pd.concat(residuals).to_csv(ROOT/'equity_holdings_residuals.csv',index=False)
pd.DataFrame(sectors).to_csv(ROOT/'equity_sector_inputs.csv',index=False)
pd.DataFrame(checks).to_csv(ROOT/'exhibits/E20_holdings_source_checks.csv',index=False)
print(pd.DataFrame(checks).to_string(index=False))

p = ROOT/'SAA_Round1_analysis.ipynb'
nb = json.loads(p.read_text(encoding='utf-8'))
for cell in nb['cells']:
    s = ''.join(cell['source'])
    if cell['cell_type']=='code' and 'holdings = pd.read_csv("equity_holdings_inputs.csv"' in s:
        s = s.replace('for field in ["Sector","Country"]:', 'for field in ["Sector"]:')
        s = s.replace('totals_field.to_csv(f"exhibits/E16_equity_{field.lower()}_exposure.csv")',
                      'totals_field.to_csv(f"exhibits/E16_equity_{field.lower().replace(chr(32), chr(95))}_exposure.csv")')
        cell['source'] = s.splitlines(True)
    if cell['cell_type']=='markdown' and s.startswith('### 12.1 ETF screening'):
        cell['source'] += ['\n**Imported holdings:** sector classifications are FactSet taxonomy, not GICS. Ticker suffixes supply listing markets only; issuer domicile and revenue geography remain unavailable. VOO/VTV snapshots are August 2026, IEFA/EEM September 2026. Cash and derivative residuals are retained separately, including negative EEM cash.\n']

heading='## 13. Equity holdings exhibits'
pos=next((i for i,c in enumerate(nb['cells']) if ''.join(c['source']).startswith(heading)),len(nb['cells']))
nb['cells']=nb['cells'][:pos]
def add(kind,text):
    c={'cell_type':kind,'id':uuid.uuid4().hex[:8],'metadata':{},'source':text.splitlines(True)}
    if kind=='code':c.update(execution_count=None,outputs=[])
    nb['cells'].append(c)

add('markdown','''## 13. Equity holdings exhibits — sectors, stock countries and overlap
These figures extend the asset-class/geography presentation used in the prior AMC reports, especially Aura, and the ETF-level exposure discussions in Apex, Pig Capital and WhiteRock. They describe the holdings inside the four equity ETFs; they do not change the allocation or repeat the return correlations.

**Definitions and limits.** Sectors follow FactSet's supplied taxonomy. Listing-market suffixes identify the market on which a security is quoted, not issuer domicile or revenue exposure: Hong Kong listings and US ADRs are not relabeled as Chinese or US companies. Source dates differ between ETFs. This is a mixed-date descriptive snapshot weighted using the chosen SAA, not a backtest of historical holdings. ETF-internal cash/derivatives are separated, including signed cash residuals, without inventing a country. No claim about an ETF's AUM is derived from a parent fund's holdings market value.
''')
add('markdown','''### E20 — Sector look-through and the value tilt
Use only top-level sector totals in the FactSet hierarchical export. Subsector and company rows are not summed again. Report both the percentage of the whole portfolio and the percentage of the four-ETF equity sleeve. The provider's unclassified categories remain visible. A separate comparison shows VOO versus VTV; changes in sector exposure describe the tilt, not a guarantee of defensiveness or superior returns.
''')
add('code','''# Sector totals reconcile to the four equity ETF weights, including their small residual categories.
from pathlib import Path
sector_input = pd.read_csv("equity_sector_inputs.csv")
holdings_detail = pd.read_csv("equity_holdings_inputs.csv",keep_default_na=False)
residual_input = pd.read_csv("equity_holdings_residuals.csv")
holdings_detail["SAA security weight"] = holdings_detail["Weight percent"]/100 * holdings_detail["ETF"].map(W[SAA])
equity_etfs = ASSETS[:4]
equity_capital = float(W[SAA].loc[equity_etfs].sum())
source_dates = holdings_detail.groupby("ETF")["Data date"].first()
date_caption = "; ".join(f"{etf}: {source_dates.loc[etf]}" for etf in equity_etfs)
sector_matrix = sector_input.pivot(index="Sector",columns="ETF",values="Weight percent").fillna(0).reindex(columns=equity_etfs)
assert np.allclose(sector_matrix.sum().to_numpy(),100)
sector_report = pd.DataFrame({"Whole portfolio percent":sector_matrix@W[SAA].loc[equity_etfs],
                              "Equity ETF sleeve percent":sector_matrix@W[SAA].loc[equity_etfs]/equity_capital})
assert abs(sector_report["Whole portfolio percent"].sum()-100*equity_capital)<1e-6
sector_report=sector_report.sort_values("Whole portfolio percent",ascending=False)
display(sector_report)
sector_report.to_csv("exhibits/E20_sector_lookthrough.csv")
sector_matrix.to_csv("exhibits/E20_sectors_by_etf.csv")
fig, axes = plt.subplots(1,2,figsize=(12,6))
d=sector_report["Equity ETF sleeve percent"].sort_values()
axes[0].barh(d.index,d.values,color=S1)
axes[0].set_xlabel("% of four equity ETF sleeve"); axes[0].set_title("Sector look-through: FactSet classification")
for j,value in enumerate(d):axes[0].text(value+.15,j,f"{value:.1f}",va="center",fontsize=7)
tilt=sector_matrix[["VOO","VTV"]].copy()
tilt["Value minus core (percentage points)"]=tilt["VTV"]-tilt["VOO"]
tilt=tilt.sort_values("Value minus core (percentage points)")
axes[1].barh(tilt.index,tilt.iloc[:,2],color=[S2 if x<0 else S1 for x in tilt.iloc[:,2]])
axes[1].axvline(0,color=INK_2,lw=.8); axes[1].set_title("VTV minus VOO: sector tilt")
axes[1].set_xlabel("Percentage-point difference within each ETF")
fig.suptitle("Equity sectors and the US value tilt",fontsize=13)
fig.tight_layout(rect=(0,.05,1,.94));fig.text(.01,.01,date_caption,fontsize=7)
fig.savefig("exhibits/E20_sector_lookthrough.png",dpi=200,bbox_inches="tight");plt.show()
tilt.to_csv("exhibits/E20_value_sector_tilt.csv")
''')
add('markdown','''### E22 — Security overlap between the equity ETFs
This differs from return correlation. Match holdings by the supplied FactSet security identifier (CUSIP/CINS-style IDs); different share classes and ADR/local lines remain separate securities. For each ETF normalize the non-negative equity holdings to 100% of its identified stock allocation, excluding cash and derivatives. Weighted overlap is the sum of the smaller normalized weights across matching securities, bounded between 0 and 100%. This is security-level overlap, not issuer-level or economic exposure overlap. VOO/VTV share a snapshot date; comparisons to IEFA/EEM use different dates.
''')
add('code','''stock_weights=holdings_detail.pivot(index="Holding identifier",columns="ETF",values="Weight percent").fillna(0).reindex(columns=equity_etfs)
stock_weights=stock_weights.div(stock_weights.sum(),axis=1)
weighted_overlap=pd.DataFrame(index=equity_etfs,columns=equity_etfs,dtype=float)
shared_counts=pd.DataFrame(index=equity_etfs,columns=equity_etfs,dtype=int)
for a in equity_etfs:
    for b in equity_etfs:
        weighted_overlap.loc[a,b]=np.minimum(stock_weights[a],stock_weights[b]).sum()*100
        shared_counts.loc[a,b]=int(((stock_weights[a]>0)&(stock_weights[b]>0)).sum())
assert np.allclose(np.diag(weighted_overlap),100)
assert weighted_overlap.min().min()>=0 and weighted_overlap.max().max()<=100+1e-6
display(weighted_overlap,shared_counts)
weighted_overlap.to_csv("exhibits/E22_weighted_security_overlap.csv")
shared_counts.to_csv("exhibits/E22_common_security_counts.csv")
fig,ax=plt.subplots(figsize=(5.7,4.8));im=ax.imshow(weighted_overlap,cmap="Blues",vmin=0,vmax=100)
ax.set_xticks(range(4),equity_etfs);ax.set_yticks(range(4),equity_etfs)
for i in range(4):
    for j in range(4):ax.text(j,i,f"{weighted_overlap.iloc[i,j]:.1f}%",ha="center",va="center",color="white" if weighted_overlap.iloc[i,j]>60 else INK)
ax.set_title("Weighted security overlap: equity-normalized")
fig.colorbar(im,ax=ax,label="Overlap (%)")
fig.tight_layout(rect=(0,.06,1,1));fig.text(.01,.01,"Security identifiers matched; ADRs and different share classes are distinct. Mixed source dates.",fontsize=7)
fig.savefig("exhibits/E22_weighted_security_overlap.png",dpi=200,bbox_inches="tight");plt.show()
''')
add('markdown','''### E23 — Largest stock positions and concentration
Combine identical security identifiers across ETFs, then show their weight in the whole USD 100 million portfolio and inside its equity ETF sleeve. Do not merge different share classes or ADRs into a single company without issuer identifiers. The top-ten concentration table is computed separately within each ETF, including its original fund-weight denominator. Date differences and internal residuals are retained in the source checks.
''')
add('code','''largest=holdings_detail.groupby("Holding identifier").agg({"SAA security weight":"sum","Holding name":"first","Sector":"first","ETF":lambda x:", ".join(sorted(set(x)))})
largest["Whole portfolio percent"]=largest["SAA security weight"]*100
largest["Equity ETF sleeve percent"]=largest["Whole portfolio percent"]/equity_capital
largest=largest.sort_values("Whole portfolio percent",ascending=False)
largest.to_csv("exhibits/E23_combined_security_positions.csv")
display(largest.head(15))
concentration=[]
for etf in equity_etfs:
    frame=holdings_detail.loc[holdings_detail["ETF"]==etf].sort_values("Weight percent",ascending=False)
    concentration.append({"ETF":etf,"Source date":source_dates[etf],"Equity securities":len(frame),
                          "Largest stock percent of ETF":frame["Weight percent"].iloc[0],
                          "Top 10 stocks percent of ETF":frame["Weight percent"].head(10).sum()})
concentration=pd.DataFrame(concentration).set_index("ETF")
display(concentration);concentration.to_csv("exhibits/E23_etf_concentration.csv")
fig,axes=plt.subplots(1,2,figsize=(12,5))
top=largest.head(12).iloc[::-1]
axes[0].barh(top["Holding name"],top["Whole portfolio percent"],color=S1)
for i,v in enumerate(top["Whole portfolio percent"]):axes[0].text(v+.015,i,f"{v:.2f}%",va="center",fontsize=8)
axes[0].set_xlabel("% of entire portfolio");axes[0].set_title("Largest combined security positions")
axes[0].set_xlim(0,top["Whole portfolio percent"].max()*1.2)
axes[1].bar(concentration.index,concentration["Top 10 stocks percent of ETF"],color=S1)
for i,v in enumerate(concentration["Top 10 stocks percent of ETF"]):axes[1].text(i,v+.5,f"{v:.1f}%",ha="center",fontsize=8)
axes[1].set_ylabel("% of each ETF");axes[1].set_ylim(0,concentration["Top 10 stocks percent of ETF"].max()*1.18)
axes[1].set_title("Top-ten stock concentration")
fig.tight_layout(rect=(0,.06,1,1));fig.text(.01,.01,date_caption+". Security-level, not issuer-level aggregation.",fontsize=7)
fig.savefig("exhibits/E23_stock_concentration.png",dpi=200,bbox_inches="tight");plt.show()
''')
p.write_text(json.dumps(nb,ensure_ascii=False,indent=1),encoding='utf-8')
print('Holdings imported; section 13 added.')
