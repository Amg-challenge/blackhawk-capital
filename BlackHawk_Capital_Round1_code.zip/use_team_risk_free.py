"""Switch the analysis to a team-built FRED monthly yield proxy."""
from pathlib import Path
import json
import hashlib
import pandas as pd

root = Path(__file__).resolve().parent
daily_path = root/'rf_dgs1mo_daily.csv'
daily = pd.read_csv(daily_path,index_col=0,parse_dates=True)
annual_percent = pd.to_numeric(daily['DGS1MO'],errors='raise').dropna()
assert annual_percent.index.is_unique and annual_percent.index.is_monotonic_increasing
monthly = annual_percent.resample('ME').mean()/1200
assert monthly.notna().all()
monthly.rename('DGS1MO').to_csv(root/'rf_team_monthly.csv')
policy_path = root/'report_policy_inputs.json'
policy = json.loads(policy_path.read_text(encoding='utf-8'))
policy.update(risk_free_origin='Team download from FRED DGS1MO; team-computed monthly yield proxy. Course file retained only for a reference comparison.',
    risk_free_active_file='rf_team_monthly.csv',
    risk_free_active_file_sha256=hashlib.sha256((root/'rf_team_monthly.csv').read_bytes()).hexdigest(),
    risk_free_monthly_conversion='Team computation: arithmetic mean of available daily annualized yields in each calendar month / 100 / 12. Missing daily observations excluded, not filled.',
    cvol_definition='User-confirmed 2026-10-12: daily consolidated trading volume in shares/ETF units; provider help not archived.',
    screening_notes='CVol share units confirmed by user. Close price times consolidated share volume approximates daily dollar turnover; it is not actual transaction-value data. ETF expenses already reflected in returns.')
policy_path.write_text(json.dumps(policy,indent=2),encoding='utf-8')
screen_path = root/'etf_screening_inputs.csv'
screen = pd.read_csv(screen_path,keep_default_na=False)
screen['CVol units confirmed as shares'] = 'Yes; user confirmation 2026-10-12'
screen['CVol definition source'] = 'User confirmation; provider field-help document not archived'
screen['Notes'] = screen['Notes'].str.replace('CVol field definition remains unverified.','CVol is daily consolidated shares, confirmed by user.',regex=False)
screen['Notes'] = screen['Notes'].str.replace('Spread horizon and Price History CVol definition are unverified.','Spread horizon is unspecified. CVol share units confirmed by user.',regex=False)
screen.to_csv(screen_path,index=False)

path = root/'SAA_Round1_analysis.ipynb'
nb = json.loads(path.read_text(encoding='utf-8'))
new_load = '''prices = pd.read_csv("etf_adj_prices.csv", index_col=0, parse_dates=True)[ASSETS]  # total return
close = pd.read_csv("etf_close_prices.csv", index_col=0, parse_dates=True)[ASSETS]   # raw closing prices
# Our own FRED download is the active risk-free source, not the course monthly file.
rf_daily_source = pd.read_csv("rf_dgs1mo_daily.csv",index_col=0,parse_dates=True)
assert rf_daily_source.columns.tolist() == ["DGS1MO"]
assert rf_daily_source.index.is_unique and rf_daily_source.index.is_monotonic_increasing
rf_daily_yields = pd.to_numeric(rf_daily_source["DGS1MO"],errors="raise").dropna()
rf_m = rf_daily_yields.resample("ME").mean()/1200
assert rf_m.notna().all(), "A full calendar month has no available daily yields"
rf_m.rename("DGS1MO").to_csv("rf_team_monthly.csv")
validate_prices(prices, "Total return")
validate_prices(close, "Raw close")
assert prices.index.equals(close.index), "Price files use different dates"
assert not prices.isna().any().any() and not close.isna().any().any()
assert rf_m.index.is_unique and rf_m.index.is_monotonic_increasing
prices.tail()
'''
new_check = '''rf_file = Path("rf_team_monthly.csv")
rf_hash = hashlib.sha256(rf_file.read_bytes()).hexdigest()
assert rf_hash == policy_inputs["risk_free_active_file_sha256"], "Team monthly risk-free changed: update source provenance"
daily_source = Path("rf_dgs1mo_daily.csv")
assert hashlib.sha256(daily_source.read_bytes()).hexdigest() == policy_inputs["risk_free_daily_file_sha256"], "Daily FRED source changed"
rf_coverage = rf_m.reindex(R.index)
assert rf_coverage.notna().all()
reconstruction_match = True  # active monthly series is computed directly from the archived daily source
rf_check = pd.DataFrame({"Team monthly decimal":rf_coverage,
    "Mean annualized yield percent":rf_coverage*1200})
course_reference_file = Path("rf_1m_tbill.csv")
course_reference_match = None
if course_reference_file.exists():
    assert hashlib.sha256(course_reference_file.read_bytes()).hexdigest() == policy_inputs["risk_free_original_file_sha256"]
    course_reference = pd.read_csv(course_reference_file,index_col=0,parse_dates=True).iloc[:,0].reindex(R.index)
    rf_check["Course monthly reference (not used)"] = course_reference
    rf_check["Team minus course reference"] = rf_coverage-course_reference
    course_reference_match = bool(course_reference.notna().all() and rf_check["Team minus course reference"].abs().max()<1e-12)
    print("Agreement with optional course reference:",course_reference_match)
print("Active source: team FRED download; monthly mean of available annual-percent yields / 1200.")
rf_check.to_csv("exhibits/E17_risk_free_validation.csv")
display(rf_check.tail())
provenance = {key:value for key,value in policy_inputs.items() if key.startswith("risk_free")}
provenance.update({"Current active file SHA256":rf_hash,"First used month":str(R.index.min().date()),
    "Last used month":str(R.index.max().date()),"Course reference matched":course_reference_match})
Path("exhibits/E17_risk_free_provenance.json").write_text(json.dumps(provenance,indent=2),encoding="utf-8")
'''
old_check = None
for c in nb['cells']:
    s = ''.join(c['source'])
    if c['cell_type'] == 'code' and s.startswith('prices = pd.read_csv'):
        s = new_load
    elif c['cell_type'] == 'code' and s.startswith('rf_file = Path'):
        old_check = s; s = new_check
    elif s.startswith('## 1. Loading the data'):
        s = '''## 1. Loading the data
Load the ETF total-return and raw-close files. Build our own monthly risk-free input from the team's daily FRED DGS1MO download: average the available annualized percentage yields within each calendar month and divide by 100 and by 12. Save the derived series to `rf_team_monthly.csv`. This is the active input for every Sharpe calculation; the professor's file is retained only as an optional comparison in section 12.2.
'''
    elif s.startswith('### 12.2 Risk-free provenance'):
        s = '''### 12.2 Team risk-free source, conversion and reference comparison
**Active source:** the team's FRED download of DGS1MO, containing annualized one-month constant-maturity Treasury yields in percent from 1 October 2012 to 30 September 2026. Section 1 computes our monthly decimal proxy as the mean of available daily observations in each calendar month divided by 1200. Missing daily observations are excluded, not filled. The derived input is `rf_team_monthly.csv`; it covers every complete month used in the backtest. Both raw and processed input fingerprints are recorded.

The professor's monthly file is an optional validation reference only and is not an input to portfolio performance. The comparison agrees to numerical precision. This proxy is a converted Treasury yield, not a realized Treasury-bill total-return index. It contains no incomplete October month. If the daily source is refreshed, update the source fingerprints and rerun the whole notebook.
'''
    elif s.startswith('### 12.1 ETF screening'):
        s = '''### 12.1 ETF screening and holdings
The FactSet overview PDFs provide rounded fund AUM, reported Average Spread and net expense ratios. AUM and trading statistics are dated 9 October 2026; holdings retain their separate source dates. The spread averaging horizon is unspecified, so do not label it a 30-day median. Read fund AUM from Fund Statistics, not Segment Details.

The user confirmed that Price History CVol is daily consolidated trading volume in shares/ETF units (12 October 2026); provider field help has not been archived. Approximate daily dollar turnover as raw closing price multiplied by CVol. Show the last 60 trading sessions, mean and median approximate dollar turnover, and target position divided by mean daily turnover. Closing price times share volume differs from actual traded dollar value: these are capacity diagnostics, not a market-impact model. Overview daily volumes can differ in venue coverage and rounding and do not replace the 60-session history.

The user also confirmed that Gross Total Return reinvests dividends and Price is the raw close. ETF expenses are already reflected in historical returns and are not deducted again. Separate full holdings, sector and stock-country exports remain the sources for equity composition and weighted security overlap. Missing inputs remain disclosed.
'''
    s = s.replace('Average CVol (verify share units)','Average daily consolidated share volume')
    s = s.replace('Average USD volume (if CVol is shares)','Average approximate USD volume')
    s = s.replace('Median USD volume (if CVol is shares)','Median approximate USD volume')
    s = s.replace('The spread horizon and CVol field definition remain source limitations;',
        'The spread horizon remains unspecified; CVol share units were confirmed by the user;')
    s = s.replace('The existing 60-session CVol diagnostics remain conditional until the Price History field definition is confirmed.',
        'CVol is daily consolidated share volume, confirmed by the user. The 60-session Price × CVol diagnostics approximate dollar turnover using closing prices; no provider help document is archived.')
    if 'register = pd.read_csv' in s:
        s = s.replace('"rf_1m_tbill.csv":"Unmodified course monthly DGS1MO file; daily-mean / 1200 conversion verified against FRED",',
            '"rf_team_monthly.csv":"Active input: team-computed monthly mean of FRED annualized yields / 1200",\n    "rf_1m_tbill.csv":"Course reference only; not used for performance",')
        s = s.replace('("Course risk-free origin","ready","File fingerprint recorded")',
            '("Team risk-free origin","ready","Own FRED download; raw and processed fingerprints recorded")')
        s = s.replace('"Archived daily FRED export; monthly mean / 1200 agrees with course file"',
            '"Own monthly mean / 1200 series; course data used only as optional comparison"')
    c['source'] = s.splitlines(True)
nb_path = path
nb_path.write_text(json.dumps(nb,ensure_ascii=False,indent=1),encoding='utf-8')
# Keep the report-section builder aligned with the active provenance cell.
builder = root/'prepare_report_inputs.py'
s = builder.read_text(encoding='utf-8')
start = s.index("code('''rf_file = Path")
end = s.index("''')",start)+4
s = s[:start]+"code('''"+new_check+"''')"+s[end:]
s = s.replace('Average CVol (verify share units)','Average daily consolidated share volume')
s = s.replace('Average USD volume (if CVol is shares)','Average approximate USD volume')
s = s.replace('Median USD volume (if CVol is shares)','Median approximate USD volume')
builder.write_text(s,encoding='utf-8')
print('Active risk-free: rf_team_monthly.csv,',len(monthly),'months. CVol interpretation recorded as user-confirmed.')
