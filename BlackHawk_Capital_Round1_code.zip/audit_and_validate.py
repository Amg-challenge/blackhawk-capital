"""Audit repairs and clean, sequential execution of the AMC notebook."""
import json
from pathlib import Path
import uuid

p = Path('SAA_Round1_analysis.ipynb')
nb = json.loads(p.read_text(encoding='utf-8'))
backup = Path('SAA_Round1_analysis_pre_audit.ipynb.bak')
if not backup.exists():
    backup.write_bytes(p.read_bytes())

helpers = '''
# Data validation and complete-calendar-month convention used throughout.
def validate_prices(frame, label):
    if not isinstance(frame.index, pd.DatetimeIndex) or frame.index.has_duplicates:
        raise ValueError(f"{label}: dates must be unique datetime values")
    if not frame.index.is_monotonic_increasing:
        raise ValueError(f"{label}: dates must be sorted")
    valid = frame.dropna()
    if valid.empty or not np.isfinite(valid.to_numpy()).all() or (valid <= 0).any().any():
        raise ValueError(f"{label}: invalid price values")

def monthly_returns(panel):
    panel = panel.sort_index()
    starts = [panel[c].first_valid_index() for c in panel]
    ends = [panel[c].last_valid_index() for c in panel]
    if any(d is None for d in starts + ends):
        raise ValueError("An asset has no valid observations")
    start, end = max(starts), min(ends)
    common = panel.loc[start:end].copy()
    # Do not forward-fill stale prices beyond any asset's final observation.
    common = common.ffill(limit=3).dropna()
    monthly_panel = common.resample("ME").last()
    # Conservative convention: exclude the calendar month of the latest data.
    monthly_panel = monthly_panel.loc[monthly_panel.index.to_period("M") < end.to_period("M")]
    result = monthly_panel.pct_change(fill_method=None).dropna()
    if len(result) < WINDOW:
        raise ValueError("Insufficient complete monthly observations")
    return result

def checked_minimize(objective, x0, **kwargs):
    result = minimize(objective, x0, **kwargs)
    if not result.success or not np.isfinite(result.x).all():
        raise RuntimeError(f"Optimization failed: {result.message}")
    for constraint in kwargs.get("constraints", []):
        value = np.asarray(constraint['fun'](result.x))
        violation = np.max(np.abs(value)) if constraint['type'] == 'eq' else -np.min(value)
        if violation > 1e-6:
            raise RuntimeError(f"Constraint violation: {violation}")
    for weight, (lower, upper) in zip(result.x, kwargs.get('bounds', [])):
        if weight < lower-1e-6 or weight > upper+1e-6:
            raise RuntimeError("Optimization violated weight bounds")
    return result

def drawdown(r):
    wealth = (1+r).cumprod()
    return wealth / wealth.cummax().clip(lower=1.0) - 1
'''

for c in nb['cells']:
    s = ''.join(c['source'])
    if c['cell_type'] == 'code':
        if 'ASSETS = list(TICKERS)' in s and 'def monthly_returns' not in s:
            s += '\n' + helpers
        if 'prices = pd.read_csv' in s and 'rf_m' in s and 'validate_prices(prices, "Total return")' not in s:
            s += '\nvalidate_prices(prices, "Total return")\nvalidate_prices(close, "Raw close")\nassert prices.index.equals(close.index), "Price files use different dates"\nassert not prices.isna().any().any() and not close.isna().any().any()\nassert rf_m.index.is_unique and rf_m.index.is_monotonic_increasing\n'
        if 'monthly = prices.resample' in s:
            s = '''R = monthly_returns(prices)
rf = rf_m.reindex(R.index)
assert rf.notna().all(), "Missing risk-free observations; update the source instead of silently filling."
print(f"{len(R)} complete months: {R.index.min().date()} to {R.index.max().date()}")
print("Latest calendar month excluded consistently from estimation and backtests.")
R.tail()
'''
        if 'def perf(' in s:
            s = s.replace('(wealth / wealth.cummax() - 1).min()', 'drawdown(r).min()')
        if 'mu = est.sub' in s:
            s = s.replace('rf.iloc[-WINDOW:]', 'rf.reindex(est.index)')
        # Validate all allocation optimizers, including alternate-universe fits.
        s = s.replace('return minimize(', 'return checked_minimize(')
        if 'def checked_minimize' in s:
            s = s.replace('result = checked_minimize(objective, x0, **kwargs)', 'result = minimize(objective, x0, **kwargs)')
        if 'SAA = "ERC cap"' in s and 'assert abs(w_saa.sum()-1)' not in s:
            s += '\nassert abs(w_saa.sum()-1) < 1e-6\nassert (w_saa >= -1e-8).all()\nassert VOL_MIN <= port_vol(w_saa, Vv) <= VOL_MAX, "Chosen SAA is outside the AMC risk band"\nassert w_saa.iloc[:4].sum() <= .50 + 1e-6\n'
        if 'rows, dates, prevw, turn' in s:
            s = s.replace('if prevw[m] is not None: turn[m].append(np.abs(w - prevw[m]).sum() / 2)\n        prevw[m] = w',
                'if prevw[m] is not None: turn[m].append(np.abs(w - prevw[m]).sum() / 2)\n        realized = float(R.iloc[t].values @ w)\n        prevw[m] = w * (1 + R.iloc[t].values) / (1 + realized)  # drifted holdings before next rebalance')
        if 'cost = 0.0 if prevw[m]' in s:
            s = s.replace('net[m].append(r - cost); prevw[m] = w', 'net[m].append((1-cost)*(1+r)-1); prevw[m] = w*(1+R.iloc[t].values)/(1+r)')
        if 'def test_addition' in s:
            s = s.replace('Rx = px[cols].ffill().dropna().resample("ME").last().pct_change().dropna()', 'Rx = monthly_returns(px[cols])')
            s = s.replace('rfx = rf.reindex(Rx.index).ffill()', 'rfx = rf.reindex(Rx.index)')
            s = s.replace('MARGIN = 0.03   # an OOS Sharpe gain below this is within estimation noise over ~108 months (SE ~ 0.10)', 'MARGIN = 0.03   # discretionary practical threshold, chosen after inspection; NOT a significance test')
            s = s.replace('(a smaller gain is within noise over {len(R)-60} months).', '(a discretionary threshold, not a statistical significance test; sample: {len(R)-60} months).')
            s = s.replace('-> essentially the same bet.', '-> substantial historical overlap; this alone does not prove redundancy.')
        if 'def _metrics(' in s:
            s = s.replace('Rp = panel[cols].ffill().dropna().resample("ME").last().pct_change().dropna()', 'Rp = monthly_returns(panel[cols])')
            s = s.replace('Each current ETF is the best choice for its role;', 'These tests do not establish that each current ETF is optimal;')
            s = s.replace('-> noise).', '-> descriptive difference, not a significance test).')
            s = s.replace('ax.set_title("No substitution materially beats the current 8 ETFs")', 'ax.set_title("Exploratory comparison of ETF substitutions")')
            s = s.replace('ax.set_xlim(0.50, 0.63)', 'ax.set_xlim(0, max(float(subt["OOS Sharpe"].max()), base_oos)*1.25)')
        if 'var_norm = var_normal' in s and 'var_hist' in s:
            s = s.replace('var_norm = var_normal(port_vol(W[SAA], Vv))', 'var_norm = var_normal(r_saa.std()*np.sqrt(12))')
        s = s.replace('wealth / wealth.cummax()', 'wealth / wealth.cummax().clip(lower=1.0)')
        s = s.replace('cum/cum.cummax()', 'cum/cum.cummax().clip(lower=1.0)')
        s = s.replace('wl_s/wl_s.cummax()', 'wl_s/wl_s.cummax().clip(lower=1.0)')
        s = s.replace('wl_h/wl_h.cummax()', 'wl_h/wl_h.cummax().clip(lower=1.0)')
        s = s.replace('delta = min(b2 / d2, 1.0)', 'delta = min(max(b2 / d2, 0.0), 1.0) if d2 > 0 else 0.0')
        if 'E8_etf_screening_TEMPLATE.csv' in s:
            # Preserve filled screening files; the generated file remains explicitly a template.
            pass
        c['outputs'] = []
        c['execution_count'] = None
    else:
        replacements = {
          '## 2. Monthly returns': '''## 2. Monthly returns
**Audit convention:** use complete calendar months only; do not treat a month-to-date return as a full month. The latest calendar month is excluded conservatively throughout all tests. Raw closing prices for share conversion remain available separately.''',
          '## 8. Backtest with monthly rebalancing': '''## 8. Fixed-allocation historical simulation
Apply today's weights to all historical months, rebalancing monthly. This describes the current allocation retrospectively. Recent observations overlap estimation, and earlier observations precede information used to choose today's weights: this is not an independent out-of-sample validation. Differences from ex-ante Sharpe also reflect different periods and regimes, not necessarily overfitting.''',
          '## 8b. OUT-OF-SAMPLE': '''## 8b. Chronological walk-forward evaluation
Estimate weights on the preceding 60 complete months and apply them to the following month. This avoids future returns in each numerical fit. However, the universe and caps were chosen after inspecting the whole history, so model-selection bias remains. This tests a monthly re-estimated method, not the fixed Bloomberg portfolio. Turnover includes weight drift before rebalancing.''',
          '### 10.1 Minimum Variance': '''### 10.1 Minimum Variance diagnostic
This diagnostic minimizes volatility with long-only weights, full investment and the asset caps, but intentionally omits the 7% floor. A result below 7% is not an admissible SAA. It does not disprove Minimum Variance: a properly AMC-constrained version could be tested separately.''',
          '### 10.3 Sensitivity': '''### 10.3 Sensitivity to the estimation window
Re-estimate capped ERC with 36, 60, 120 months and the complete common history. These are robustness diagnostics. The official compliance volatility must always be assessed with the most recent 60 complete monthly returns. Changes in weights or risk estimates are reported without assuming stability in advance.''',
          '### 10.4 Transaction costs': '''### 10.4 Transaction costs
Apply an assumed 10 bps per dollar bought or sold. Compare target weights to holdings drifted by the preceding month's asset returns. Even Equal Weight has non-zero rebalancing turnover. Initial establishment costs are excluded consistently. These are sensitivity assumptions, not observed spreads; net returns use (1-cost)*(1+gross return)-1.''',
          '### 10.5 Empirical': '''### 10.5 Historical VaR and Expected Shortfall
Compare the zero-mean normal approximation with the historical 5th percentile and the mean return in the worst 5% of months, all on the same fixed-allocation history. The ex-ante VaR on the latest 60 months is reported separately. Expected Shortfall and VaR are different quantities; a larger shortfall does not itself prove non-normal tails.''',
          '### 10.6 Testing': '''### 10.6 Exploratory additions to the universe
Add TIP, LQD, EMB, USMV or VNQ one at a time, re-estimating capped ERC. Report correlations and historical and walk-forward performance. The largest pairwise correlation is a description of overlap, not a sufficient reason to reject an ETF. Each added asset has a discretionary 12% cap. The +0.03 Sharpe threshold was introduced after inspecting results and is not a statistical significance test. Results support a choice under this protocol, not a proof that the universe is complete or optimal.''',
          '### 10.7 Substituting': '''### 10.7 Exploratory substitutions within sleeves
Keep eight ETFs and replace one instrument at a time. Transfer the outgoing asset's cap to the replacement and compare with the baseline on the same complete monthly period. Seven sleeves are covered; the broad-commodity sleeve is not tested. TIP versus IGSB changes the economic exposure (real-rate/inflation versus corporate credit), not just the implementation. An allocation outside the band under this weighting rule could still be made admissible using another weighting rule. Small differences are reported without claims of statistical significance or universal optimality.''',
          '### 10.8 Stress': '''### 10.8 Historical stress windows and hypothetical shocks
Historical windows replay today's fixed allocation and are retrospective. Hypothetical one-month shocks are explicit user-defined scenarios, not calibrated probabilities or forecasts. Results are conditional on the assumed shocks; they cannot prove protection in every inflationary regime. Portfolio drawdowns use initial wealth of USD 1 as the first high-water mark.''',
          '### E10': '''### E10 — Rolling Sharpe and volatility
36-month realized statistics for fixed-weight historical portfolios. The shaded 7–9% band is the ex-ante formation requirement, not a realized-risk guarantee. The challenge also compares realized risk with the target. Judge the displayed results directly; do not assume the allocation stayed inside the band.''',
          '### E12': '''### E12 — Performance across time horizons
Show the final 12, 36 and 60 complete months and the entire common history. Short favorable windows must not be presented as forecasts. Report which crises each interval includes and keep the full-sample comparison visible.'''
        }
        for key, value in replacements.items():
            if s.startswith(key):
                s = value + '\n'
                break
        s = s.replace('The robust rules (EW, RP, ERC) use only risk; MVO also uses `mu` and is the most fragile out of sample.', 'Equal Weight estimates no inputs; inverse-volatility Risk Parity and ERC estimate risk. Maximum Sharpe also estimates expected excess returns. More estimated inputs can increase estimation risk; realized performance must be assessed rather than assumed.')
        s = s.replace('PDBC', 'the untested alternative')
    c['source'] = s.splitlines(True)
    c.setdefault('id', uuid.uuid4().hex[:8])

p.write_text(json.dumps(nb,ensure_ascii=False,indent=1),encoding='utf-8')

if __name__ == '__main__':
    import sys
    from IPython.core.interactiveshell import InteractiveShell
    from IPython.utils.capture import capture_output
    from traitlets.config import Config
    config = Config()
    config.HistoryManager.enabled = False
    shell = InteractiveShell.instance(config=config)
    shell.run_cell('''import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from IPython.display import display, Image
import io
def _audit_show(*args, **kwargs):
    for number in plt.get_fignums():
        figure = plt.figure(number)
        buffer = io.BytesIO()
        figure.savefig(buffer, format='png', bbox_inches='tight')
        display(Image(data=buffer.getvalue()))
        plt.close(figure)
plt.show = _audit_show
''')
    count = 0
    log = []
    for i,c in enumerate(nb['cells']):
        if c['cell_type'] != 'code':
            continue
        count += 1
        with capture_output() as captured:
            result = shell.run_cell(''.join(c['source']),store_history=False)
        if result.error_in_exec or result.error_before_exec:
            print(captured.stdout, captured.stderr)
            raise RuntimeError(f'Cell {i} failed: {result.error_in_exec or result.error_before_exec}')
        c['execution_count'] = count
        if captured.stdout:
            c['outputs'].append({'output_type':'stream','name':'stdout','text':captured.stdout.splitlines(True)})
        if captured.stderr:
            c['outputs'].append({'output_type':'stream','name':'stderr','text':captured.stderr.splitlines(True)})
        for output in captured.outputs:
            c['outputs'].append({'output_type':'display_data','data':output.data,'metadata':output.metadata})
        log.append(f'PASS cell {i}: '+''.join(c['source']).splitlines()[0])
        print(log[-1], flush=True)
    p.write_text(json.dumps(nb,ensure_ascii=False,indent=1),encoding='utf-8')
    Path('audit_execution.txt').write_text('\n'.join(log),encoding='utf-8')
    print(f'All {count} code cells executed successfully')
