# -*- coding: utf-8 -*-
"""
Builds etf_adj_prices.csv and etf_close_prices.csv in the notebook's format,
starting from the Excel files exported from FactSet (Price History), one per ETF.

USAGE:
  1) In FactSet, for EACH ETF: Prices -> Price History, currency USD, Daily frequency,
     long range (Max). Download as Excel (.xlsx).
  2) Save each file in the FOLDER below, named after its ticker (e.g. VOO.xlsx).
  3) Run:  python costruisci_csv.py
"""
import pandas as pd, os

FOLDER = r"C:\Users\galdi\Downloads\Dati AMC"            # where you put the FactSet .xlsx files
DEST   = r"C:\Users\galdi\OneDrive\Desktop\AMC"          # where the two CSVs are saved

# order in which the columns will appear in the CSVs (= ASSETS in the notebook)
TICKERS = ["VOO", "VTV", "IEFA", "EEM", "IEF", "IGSB", "GLD", "DBC"]

def read_file(file):
    # find the header row (the one containing "Date")
    raw = pd.read_excel(file, header=None)
    ticker = os.path.splitext(os.path.basename(file))[0].replace('Dati ', '').upper()
    titles = raw.head(2).astype(str).to_numpy().ravel()
    identifiers = [v for v in titles if 'Price History:' in v]
    if identifiers and f'{ticker}-US' not in identifiers[0].upper():
        raise ValueError(f'Wrong instrument in {file}: {identifiers[0]}')
    hdr = raw.index[raw.apply(
        lambda r: r.astype(str).str.contains("Date", case=False).any(), axis=1)][0]
    df = pd.read_excel(file, header=hdr)
    df.columns = [str(c).strip() for c in df.columns]
    col_date  = [c for c in df.columns if c.lower().startswith("date")][0]
    col_price = [c for c in df.columns if c.lower() == "price"][0]
    col_tr    = [c for c in df.columns if "total" in c.lower() and "ret" in c.lower()][0]
    df[col_date] = pd.to_datetime(df[col_date])
    out = df.set_index(col_date)[[col_price, col_tr]]
    out.columns = ["close", "adj"]
    if out.index.has_duplicates:
        raise ValueError(f'Duplicate dates in {file}')
    valid = out.dropna()
    if valid.empty or (valid <= 0).any().any():
        raise ValueError(f'Invalid price data in {file}')
    return out.sort_index()

adj, close = {}, {}
for t in TICKERS:
    f = os.path.join(FOLDER, t + ".xlsx")
    if not os.path.exists(f):
        raise FileNotFoundError(f"Missing file: {f}")
    d = read_file(f)
    adj[t]   = d["adj"]
    close[t] = d["close"]

adj_df   = pd.DataFrame(adj)[TICKERS].sort_index()
close_df = pd.DataFrame(close)[TICKERS].sort_index()

# --- Check: two ETFs with identical series = likely a wrong export ---
for i, a in enumerate(TICKERS):
    for b in TICKERS[i+1:]:
        if adj_df[a].equals(adj_df[b]):
            raise ValueError(f'{a} and {b} have identical data: re-check the exports')

# --- Trim to the common window: drop the rows where at least one ETF is missing ---
n_before = len(adj_df)
common = adj_df.notna().all(axis=1) & close_df.notna().all(axis=1)
adj_df = adj_df.loc[common]
close_df = close_df.loc[common]
if adj_df.empty:
    raise ValueError('No common valid dates across all ETFs')
print(f"  total rows {n_before} -> common window {len(adj_df)} "
      f"({adj_df.index[0].date()} -> {adj_df.index[-1].date()})")

adj_df.to_csv(os.path.join(DEST, "etf_adj_prices.csv"), index_label="Date")
close_df.to_csv(os.path.join(DEST, "etf_close_prices.csv"), index_label="Date")

print("  columns:", list(adj_df.columns))
print(adj_df.tail(3).round(2))
