"""Import FactSet Country Portfolio Trend, retaining month labels and hierarchy."""
from pathlib import Path
import json
import re
import shutil
import uuid
import pandas as pd
from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parent
ETFS = ['VOO','VTV','IEFA','EEM']
country_rows, security_rows, checks = [], [], []
for etf in ETFS:
    source = Path(r'C:\Users\galdi\Downloads')/f'{etf} Country.xlsx'
    target = ROOT/'factset_screening'/source.name
    if source.exists():
        shutil.copy2(source,target)
    ws = load_workbook(target,data_only=True).active
    assert f'{etf}-US' in str(ws.cell(1,1).value)
    header = next(r for r in range(1,ws.max_row+1) if ws.cell(r,2).value=='Ticker')
    periods=[]
    for col in range(3,ws.max_column+1):
        label=str(ws.cell(header,col).value)
        if re.fullmatch(r'\d{2}/\d{2}',label):
            month,year=label.split('/')
            periods.append((col,f'20{year}-{month}'))
    assert periods
    parent=None
    for r in range(header+2,ws.max_row+1):
        name=ws.cell(r,1).value
        if name is None:
            continue
        if ws.cell(r,1).alignment.indent==0:
            parent=str(name).strip()
            for col,period in periods:
                weight=ws.cell(r,col).value
                if isinstance(weight,(int,float)):
                    country_rows.append({'ETF':etf,'Country':parent,'Period':period,'Weight percent':float(weight),
                                         'Source':target.name,'Definition':'FactSet Country Portfolio Trend; precise domicile/revenue convention not supplied'})
        elif ws.cell(r,1).alignment.indent==1:
            ticker=str(ws.cell(r,2).value or '')
            for col,period in periods:
                weight=ws.cell(r,col).value
                if isinstance(weight,(int,float)):
                    security_rows.append({'ETF':etf,'Ticker':ticker,'Holding name':str(name).strip(),
                                          'Country':parent,'Period':period,'Weight percent':float(weight)})
    for col,period in periods:
        total=sum(x['Weight percent'] for x in country_rows if x['ETF']==etf and x['Period']==period)
        reported=float(ws.cell(header+1,col).value)
        checks.append({'ETF':etf,'Period':period,'Country rows sum percent':total,
                       'FactSet reported total percent':reported,'Difference from 100 percentage points':100-total,
                       'Source totals reconcile':abs(total-reported)<1e-4 and abs(total-100)<.05})

pd.DataFrame(country_rows).to_csv(ROOT/'equity_country_inputs.csv',index=False)
pd.DataFrame(security_rows).to_csv(ROOT/'equity_country_security_inputs.csv',index=False)
pd.DataFrame(checks).to_csv(ROOT/'exhibits/E24_country_source_checks.csv',index=False)
print(pd.DataFrame(checks).to_string(index=False))

p=ROOT/'SAA_Round1_analysis.ipynb'
nb=json.loads(p.read_text(encoding='utf-8'))
for c in nb['cells']:
    s=''.join(c['source'])
    if c['cell_type']=='markdown' and s.startswith('## 13. Equity holdings exhibits'):
        s=s.replace('issuer domicile and revenue exposure remain unavailable',
                    'issuer domicile and revenue exposure cannot be inferred from ticker suffixes')
        s += '\n**Country supplement:** E24 uses the separate FactSet country-classification exports on a common completed-month snapshot. Only the FactSet country-classification exhibit is retained. The country and holdings snapshots are not assumed to have identical dates.\n'
        c['source']=s.splitlines(True)

heading='### E24 — FactSet country classification'
index=next((i for i,c in enumerate(nb['cells']) if ''.join(c['source']).startswith(heading)),len(nb['cells']))
nb['cells']=nb['cells'][:index]
markdown='''### E24 — FactSet country classification: common completed-month snapshot
The separate Country Portfolio Trend exports group securities by country, independently of ticker market suffixes. For example, Chinese companies listed in Hong Kong can be assigned to China by FactSet. These values are not substituted with country-of-listing estimates. The export does not document its exact country-attribution methodology, so the figure is labeled **FactSet country classification**, not revenue geography.

Use the latest completed calendar month available to all four ETFs, selected relative to the latest price date. Keep the entire reported history, including incomplete months, in the source CSV. Aggregate only top-level country rows; do not double-count their company detail. Report the small reconciliation differences from 100% rather than silently renormalizing. The chart weights country snapshots using today's SAA weights: it is a descriptive look-through, not the historical portfolio actually held at that date.

Use E24 for the country discussion. Sector/holdings snapshots remain August or September as originally reported; country snapshots must be dated separately.
'''
code='''# Actual provider country groupings, separate from ticker-suffix listing markets.
country_source=pd.read_csv("equity_country_inputs.csv")
country_checks=pd.read_csv("exhibits/E24_country_source_checks.csv")
price_month=prices.index.max().to_period("M")
period_sets=[]
for etf in equity_etfs:
    periods=set(country_checks.loc[(country_checks["ETF"]==etf)&country_checks["Source totals reconcile"],"Period"])
    period_sets.append({p for p in periods if pd.Period(p,freq="M")<price_month})
common_country_periods=set.intersection(*period_sets)
assert common_country_periods,"No completed common country snapshot"
country_period=max(common_country_periods)
country_snapshot=country_source.loc[country_source["Period"]==country_period]
country_matrix=country_snapshot.pivot(index="Country",columns="ETF",values="Weight percent").fillna(0).reindex(columns=equity_etfs)
assert (country_matrix.sum()-100).abs().max()<.05
country_report=pd.DataFrame({"Whole portfolio percent":country_matrix@W[SAA].loc[equity_etfs]})
country_report["Equity ETF sleeve percent"]=country_report["Whole portfolio percent"]/equity_capital
country_report=country_report.sort_values("Whole portfolio percent",ascending=False)
country_report["Country snapshot period"]=country_period
print("Common completed country snapshot:",country_period)
display(country_report,country_checks.loc[country_checks["Period"]==country_period])
country_report.to_csv("exhibits/E24_country_lookthrough.csv")
country_matrix.to_csv("exhibits/E24_countries_by_etf.csv")
country_reconciliation=pd.Series({"Equity ETF allocation percent":100*equity_capital,
                                  "Country-classified portfolio percent":country_report["Whole portfolio percent"].sum(),
                                  "Difference percentage points":100*equity_capital-country_report["Whole portfolio percent"].sum()})
country_reconciliation.to_csv("exhibits/E24_country_reconciliation.csv",header=["Value"])

fig,axes=plt.subplots(1,2,figsize=(11,5.3))
for ax,series,title in [(axes[0],country_report["Equity ETF sleeve percent"],"Four equity ETF sleeve"),
                        (axes[1],country_matrix["EEM"],"Inside EEM")]:
    top=series.sort_values(ascending=False).head(12).copy()
    other=series.sum()-top.sum()
    if abs(other)>1e-8:top.loc["Other countries / residual categories"]=other
    top=top.sort_values()
    ax.barh(top.index,top.values,color=S1)
    for j,v in enumerate(top):ax.text(v+.25,j,f"{v:.1f}%",va="center",fontsize=8)
    ax.set_xlim(min(0,top.min()*1.15),max(top.max()*1.23,1));ax.set_xlabel("Weight (%)");ax.set_title(title)
fig.suptitle(f"FactSet country classification — {country_period}",fontsize=13)
fig.tight_layout(rect=(0,.08,1,.94))
fig.text(.01,.02,"Common month of country exports, weighted by current SAA. Not revenue geography. Minor source reconciliation differences retained.",fontsize=7)
fig.savefig("exhibits/E24_country_lookthrough.png",dpi=200,bbox_inches="tight");plt.show()

# Preserve quarterly country trends as a table, without treating October as a completed month.
trend_rows=[]
for period,group in country_source.groupby("Period"):
    period_quality=country_checks.loc[country_checks["Period"]==period]
    if len(period_quality)!=len(equity_etfs) or not period_quality["Source totals reconcile"].all():
        print("Historical country period excluded because source country subtotals are incomplete:",period)
        continue
    matrix=group.pivot(index="Country",columns="ETF",values="Weight percent").fillna(0).reindex(columns=equity_etfs)
    aggregate=matrix@W[SAA].loc[equity_etfs]
    for country,weight in aggregate.items():
        trend_rows.append({"Period":period,"Country":country,"Whole portfolio percent under current SAA weights":weight,
                           "Completed before latest price month":pd.Period(period,freq="M")<price_month})
pd.DataFrame(trend_rows).to_csv("exhibits/E24_country_history.csv",index=False)
'''
nb['cells'].append({'cell_type':'markdown','id':uuid.uuid4().hex[:8],'metadata':{},'source':markdown.splitlines(True)})
nb['cells'].append({'cell_type':'code','id':uuid.uuid4().hex[:8],'metadata':{},'execution_count':None,'outputs':[],'source':code.splitlines(True)})
p.write_text(json.dumps(nb,ensure_ascii=False,indent=1),encoding='utf-8')
print('Country sources imported; E24 added to the existing notebook.')
