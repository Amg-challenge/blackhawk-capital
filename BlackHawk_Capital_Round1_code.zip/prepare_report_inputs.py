"""Prepare persistent inputs and documented report-readiness sections."""
import hashlib
import json
from pathlib import Path
import uuid
import pandas as pd

root = Path(__file__).resolve().parent
tickers = ['VOO','VTV','IEFA','EEM','IEF','IGSB','GLD','DBC']
raw_folder = Path(r'C:\Users\galdi\Downloads\Dati AMC')
volumes = []
for ticker in tickers:
    file = raw_folder / f'{ticker}.xlsx'
    raw = pd.read_excel(file, header=None)
    title = ' '.join(raw.head(2).astype(str).to_numpy().ravel())
    if f'{ticker}-US' not in title:
        raise ValueError(f'Instrument mismatch: {file}')
    header = next(i for i,row in raw.iterrows() if 'Date' in row.astype(str).values)
    df = pd.read_excel(file, header=header)
    df.columns = df.columns.astype(str).str.strip()
    df['Date'] = pd.to_datetime(df['Date'])
    valid = df[['Date','Price','CVol']].dropna().sort_values('Date')
    valid['Ticker'] = ticker
    valid['Source'] = 'FactSet Price History export'
    volumes.append(valid)
pd.concat(volumes).to_csv(root/'screening_volume_history.csv', index=False)

screen_path = root/'etf_screening_inputs.csv'
if not screen_path.exists():
    pd.DataFrame({'Ticker':tickers, 'Data date':'', 'Index tracked':'',
        'AUM USD billions':'', 'Expense ratio percent':'', 'Reported bid ask spread bps':'',
        'Spread measurement period':'', 'Number of holdings':'', 'Source':'',
        'CVol units confirmed as shares':'', 'Notes':''}).to_csv(screen_path,index=False)
hold_path = root/'equity_holdings_inputs.csv'
if not hold_path.exists():
    pd.DataFrame(columns=['ETF','Holding identifier','Holding name','Weight percent',
                          'Sector','Country','Data date','Source']).to_csv(hold_path,index=False)
policy_path = root/'report_policy_inputs.json'
if not policy_path.exists():
    policy_path.write_text(json.dumps({
        'drawdown_tolerance': None,
        'drawdown_status':'provisional: user requested evaluation of 15%, not a guaranteed loss limit',
        'sharpe_haircut': None,
        'sharpe_haircut_status':'team decision pending; show scenarios before choosing',
        'risk_free_original_file_sha256':hashlib.sha256((root/'rf_1m_tbill.csv').read_bytes()).hexdigest(),
        'risk_free_origin':'Unmodified course-supplied monthly file; byte-identical to original checked on 2026-10-12',
        'risk_free_series':'DGS1MO',
        'risk_free_primary_url':'https://fred.stlouisfed.org/series/DGS1MO',
        'risk_free_raw_units':'annual yield, percent per annum, daily observations',
        'risk_free_monthly_conversion':'Unverified course preprocessing. Candidate reconstruction: calendar-month mean of daily yield / 100 / 12.',
        'risk_free_conversion_verified':False,
        'screening_notes':'CVol units require confirmation in FactSet; TER is not subtracted again from fund total returns.'
    },indent=2),encoding='utf-8')

policy = json.loads(policy_path.read_text(encoding='utf-8'))

records = []
def trial(name,kind,status='recomputed in current notebook',note=''):
    records.append({'Configuration':name,'Category':kind,'Evidence status':status,'Notes':note})
for name in ['Equal Weight','Inverse-volatility Risk Parity','Uncapped ERC','Capped ERC','Constrained Maximum Sharpe','Capped Minimum Variance diagnostic']:
    trial(name,'Allocation method')
trial('Capped ERC with Ledoit-Wolf covariance','Covariance estimator')
for window in ['36 months','120 months','full common history']:
    trial('Capped ERC: '+window,'Estimation-window sensitivity',note='60 months is covered by baseline; alternate windows are diagnostics')
for candidate in ['TIP','LQD','EMB','USMV','VNQ']:
    trial('Add '+candidate,'Universe addition',note='12% discretionary candidate cap; exploratory comparison')
for out,inn in [('VOO','SPY'),('IEFA','EFA'),('EEM','VWO'),('VTV','USMV'),('IEF','TLT'),('IGSB','LQD'),('IGSB','TIP'),('IGSB','EMB'),('GLD','IAU')]:
    trial(out+' -> '+inn,'ETF substitution',note='Outgoing cap transferred; comparison uses common complete monthly window')
for name in ['Add TIP and LQD together','Add USMV and VNQ together']:
    trial(name,'Universe addition','previous chat experiment; not recomputed in current notebook','Count disclosed; not used as independently verified exhibit')
for name in ['50% capped ERC + 50% Minimum Variance','one-third capped ERC / Risk Parity / Minimum Variance',
             '50% capped ERC + 50% Equal Weight','70% capped ERC + 30% Minimum Variance']:
    trial(name,'Fixed method blend','previous chat experiment; not recomputed in current notebook')
trial('Optimized six-method blend with final 36-month holdout','Optimized blend',note='Protocol revised after initial half-history feasibility failure; all history had already been inspected')
trial('Optimized blend with initial half-history split','Protocol attempt','infeasible under imposed constraints','Record failed attempt; no performance claim')
pd.DataFrame(records).to_csv(root/'research_variants_register.csv',index=False)

notebook = root/'SAA_Round1_analysis.ipynb'
nb = json.loads(notebook.read_text(encoding='utf-8'))
tail_start = next((i for i,c in enumerate(nb['cells']) if ''.join(c['source']).startswith('## 13. Equity holdings exhibits')),len(nb['cells']))
holdings_exhibits = nb['cells'][tail_start:]
start = next((i for i,c in enumerate(nb['cells']) if ''.join(c['source']).startswith('## 12. Report readiness')),len(nb['cells']))
nb['cells'] = nb['cells'][:start]
def md(text):
    nb['cells'].append({'cell_type':'markdown','id':uuid.uuid4().hex[:8],'metadata':{},'source':text.splitlines(True)})
def code(text):
    nb['cells'].append({'cell_type':'code','id':uuid.uuid4().hex[:8],'metadata':{},'execution_count':None,'outputs':[],'source':text.splitlines(True)})

md('''## 12. Report readiness: screening, provenance and policy assumptions
This section consolidates the inputs still required for a reproducible report. Editable source files are preserved across runs. Missing inputs are reported explicitly, never replaced with fabricated values. Performance assumptions are separated from calculated results.
''')
md('''### 12.1 ETF screening and holdings
Use a common observation date for AUM, expense ratios, spreads and holdings. The local FactSet Price History exports provide a CVol field; verify that it means consolidated share volume before interpreting dollar turnover. Show the latest 60 trading sessions, median dollar volume, and the proposed position as a percentage of average daily dollar volume. These are capacity diagnostics, not an execution-cost or market-impact model.

Complete `etf_screening_inputs.csv` using FactSet fund information. Export full holdings for VOO, VTV, IEFA and EEM into `equity_holdings_inputs.csv`. Normalize percentages only when validated; require each holdings list to sum approximately to 100%. Pairwise weighted overlap equals the sum of the smaller holding weights across matching identifiers. If a list is partial, do not present its coverage as a complete sector or country allocation. TER describes ongoing fund costs, normally already reflected in market prices: do not deduct it a second time from historical total returns. Confirm the meaning of FactSet's Gross Total Return, including dividend-tax treatment, in source documentation.
''')
code('''from pathlib import Path
import json, hashlib
policy_inputs = json.loads(Path("report_policy_inputs.json").read_text(encoding="utf-8"))
screen_inputs = pd.read_csv("etf_screening_inputs.csv", keep_default_na=False).set_index("Ticker").reindex(ASSETS)
volume_history = pd.read_csv("screening_volume_history.csv", parse_dates=["Date"])
liquidity_rows = {}
for ticker in ASSETS:
    frame = volume_history.loc[volume_history["Ticker"] == ticker].sort_values("Date").tail(60)
    dollar_volume = frame["Price"] * frame["CVol"]
    liquidity_rows[ticker] = {
        "Price-history observation date":frame["Date"].max().date(),
        "Trading sessions":len(frame),
        "Average daily consolidated share volume":frame["CVol"].mean(),
        "Average approximate USD volume":dollar_volume.mean(),
        "Median approximate USD volume":dollar_volume.median(),
        "Target position USD":float(W[SAA].loc[ticker])*CAPITAL,
        "Position / average daily USD volume":float(W[SAA].loc[ticker])*CAPITAL/dollar_volume.mean()}
screening = screen_inputs.join(pd.DataFrame(liquidity_rows).T)
required_screen = ["Data date","Index tracked","AUM USD billions","Expense ratio percent",
                   "Reported bid ask spread bps","Spread measurement period","Number of holdings","Source",
                   "CVol units confirmed as shares"]
missing_screen = screening[required_screen].replace("",np.nan).isna()
screening["Screening fields missing"] = missing_screen.sum(axis=1)
screening.to_csv("exhibits/E16_etf_screening.csv")
display(screening)

holdings = pd.read_csv("equity_holdings_inputs.csv",keep_default_na=False)
equity_assets = ASSETS[:4]
holdings_ready = False
if holdings.empty:
    print("Holdings export pending: sector/country look-through and overlap not computed.")
else:
    holdings["Weight percent"] = pd.to_numeric(holdings["Weight percent"],errors="raise")
    assert (holdings["Weight percent"] >= 0).all()
    assert not holdings.duplicated(["ETF","Holding identifier"]).any(), "Duplicate holding identifiers"
    totals = holdings.groupby("ETF")["Weight percent"].sum().reindex(equity_assets)
    print("Holdings coverage (%):"); display(totals)
    holdings_ready = totals.between(98,102).all() and holdings["Holding identifier"].ne("").all()
    if holdings_ready:
        weights_by_holding = holdings.pivot(index="Holding identifier",columns="ETF",values="Weight percent").fillna(0)/100
        overlap = pd.DataFrame(index=equity_assets,columns=equity_assets,dtype=float)
        for a in equity_assets:
            for b in equity_assets:
                overlap.loc[a,b] = np.minimum(weights_by_holding[a],weights_by_holding[b]).sum()
        display(overlap); overlap.to_csv("exhibits/E16_equity_holdings_overlap.csv")
        holdings["Portfolio weight"] = holdings["Weight percent"]/100 * holdings["ETF"].map(W[SAA])
        for field in ["Sector"]:
            totals_field = holdings.groupby(field)["Portfolio weight"].sum().sort_values(ascending=False)
            totals_field.to_csv(f"exhibits/E16_equity_{field.lower().replace(chr(32),chr(95))}_exposure.csv")
            display(totals_field)
    else:
        print("Incomplete holdings: no full-portfolio look-through claim is produced.")
''')
md('''### 12.2 Risk-free provenance and optional reconstruction check
The monthly file is an unmodified course input: record its fingerprint and date coverage. Its DGS1MO label refers to the Federal Reserve H.15 one-month constant-maturity Treasury yield distributed by FRED, in percent per annum with daily observations. It is a yield proxy, not a realized monthly Treasury-bill total-return index.

The course file already contains monthly decimals. Its precise preprocessing has not been recovered from source code. A common approximation is calendar-month average daily annual yield divided by 100 and then by 12; an alternative uses the prior month-end yield. Do not describe either as verified without evidence. For a numerical reconstruction, download the original daily DGS1MO CSV from FRED as `rf_dgs1mo_daily.csv`; the optional check below compares the average-yield convention on complete months. Keep the course file unchanged unless the team deliberately changes and documents its benchmark convention. Within-month averages use information available by month-end; they are acceptable descriptive Sharpe benchmarks, but not opening-month investable forecasts.

Primary definition: https://fred.stlouisfed.org/series/DGS1MO
''')
code('''rf_file = Path("rf_team_monthly.csv")
rf_hash = hashlib.sha256(rf_file.read_bytes()).hexdigest()
assert rf_hash == policy_inputs["risk_free_active_file_sha256"], "Team monthly risk-free changed: update source provenance"
daily_source = Path("rf_dgs1mo_daily.csv")
assert hashlib.sha256(daily_source.read_bytes()).hexdigest() == policy_inputs["risk_free_daily_file_sha256"], "Daily FRED source changed"
rf_coverage = rf_m.reindex(R.index)
assert rf_coverage.notna().all()
reconstruction_match = True  # active monthly series is computed directly from the archived daily source
rf_check = pd.DataFrame({"Team monthly decimal":rf_coverage,
    "Mean annualized yield percent":rf_coverage*1200})
course_reference_file = Path("rf_1m_tbill.csv")
course_reference_match = None
if course_reference_file.exists():
    assert hashlib.sha256(course_reference_file.read_bytes()).hexdigest() == policy_inputs["risk_free_original_file_sha256"]
    course_reference = pd.read_csv(course_reference_file,index_col=0,parse_dates=True).iloc[:,0].reindex(R.index)
    rf_check["Course monthly reference (not used)"] = course_reference
    rf_check["Team minus course reference"] = rf_coverage-course_reference
    course_reference_match = bool(course_reference.notna().all() and rf_check["Team minus course reference"].abs().max()<1e-12)
    print("Agreement with optional course reference:",course_reference_match)
print("Active source: team FRED download; monthly mean of available annual-percent yields / 1200.")
rf_check.to_csv("exhibits/E17_risk_free_validation.csv")
display(rf_check.tail())
provenance = {key:value for key,value in policy_inputs.items() if key.startswith("risk_free")}
provenance.update({"Current active file SHA256":rf_hash,"First used month":str(R.index.min().date()),
    "Last used month":str(R.index.max().date()),"Course reference matched":course_reference_match})
Path("exhibits/E17_risk_free_provenance.json").write_text(json.dumps(provenance,indent=2),encoding="utf-8")
''')
md('''### 12.3 Drawdown tolerance and discounted Sharpe: explicit decisions
The team requested evaluation of a **15%** drawdown tolerance. This is provisional risk appetite, not a stop-loss, guarantee or calibrated maximum possible loss. The AMC does not allow discretionary changes to the Round 1 portfolio before the next round. Historical maximum drawdown is an observation, not an acceptable-loss policy chosen by the optimizer.

Compare the tolerance against the fixed-allocation history and the walk-forward method. The latter re-estimates monthly and is not the same portfolio held fixed in Bloomberg. A small buffer above observed drawdown is a warning about limited comfort, especially with no 2008 in the sample. Hypothetical stress outcomes remain conditional on their assumed shocks.

For Sharpe, start with the walk-forward result after the assumed transaction costs. Show 10%, 20%, 30% and 40% discretionary haircuts for selection bias, model uncertainty and limited crisis coverage. These haircuts are scenarios, not statistical confidence intervals or forecasts. Cost assumptions have already been deducted; do not deduct them again. The team selects and motivates one haircut in `report_policy_inputs.json`; until then there is no chosen realistic Sharpe.
''')
code('''fixed_series = bt[SAA]
method_series = oos[SAA]
dd_comparison = pd.DataFrame({"Observed maximum drawdown": {
    "Fixed-allocation historical simulation":drawdown(fixed_series).min(),
    "Monthly re-estimated walk-forward method":drawdown(method_series).min()}})
display(dd_comparison)
dd_comparison.to_csv("exhibits/E18_drawdown_policy_evidence.csv")
net_method_series = pd.Series(net[SAA],index=oos.index)
net_sharpe = perf(net_method_series,rf.reindex(oos.index))["Sharpe"]
chosen_haircut = policy_inputs["sharpe_haircut"]
print("Net walk-forward Sharpe:",net_sharpe)
print("Acceptable drawdown and realistic discounted Sharpe: team decisions pending. No 15% tolerance or 30% haircut is assumed.")
''')
md('''### 12.4 Research register, input manifest and delivery readiness
Disclose the configurations actually examined, including unsuccessful attempts and older chat-only experiments. The register is a minimum documented research history, not a claim that these were the only calculations ever tried. Distinguish research configurations from optimizer starting points and repeated monthly fits; a raw count of numerical calls would exaggerate the number of economic alternatives.

Universe, caps and practical thresholds were selected after viewing history. Consequently, no historical result in this project is a wholly untouched external test. Addition/substitution comparisons remain exploratory, and a low pairwise correlation or a small Sharpe advantage is not sufficient proof of superiority. Freeze the final policy before the actual challenge and retain this register.
''')
code('''register = pd.read_csv("research_variants_register.csv",keep_default_na=False)
display(register)
print("Documented configurations and protocol attempts:",len(register))
print(register.groupby("Evidence status").size().to_string())
register.to_csv("exhibits/E19_research_variants.csv",index=False)
source_notes = {
    "etf_adj_prices.csv":"FactSet Gross Total Return exports; eight primary Excel exports matched during audit",
    "etf_close_prices.csv":"FactSet Price exports; provisional share-conversion date",
    "rf_1m_tbill.csv":"Unmodified course monthly DGS1MO file; exact conversion pending reconstruction",
    "candidates_adj_prices.csv":"TIP/LQD course prices, EMB/USMV/VNQ FactSet exports; mixed source provenance",
    "substitutes_adj_prices.csv":"SPY/EFA course prices; other columns from candidate/FactSet exports"}
manifest_rows=[]
for file,source in source_notes.items():
    frame=pd.read_csv(file,index_col=0,parse_dates=True)
    manifest_rows.append({"File":file,"SHA256":hashlib.sha256(Path(file).read_bytes()).hexdigest(),
                          "Rows":len(frame),"First date":frame.index.min().date(),"Last date":frame.index.max().date(),
                          "Columns":", ".join(frame.columns),"Source":source})
manifest=pd.DataFrame(manifest_rows)
manifest.to_csv("exhibits/E19_input_manifest.csv",index=False)
display(manifest)
readiness=pd.DataFrame([
    ("Price data and numerical calculations","ready","Complete months; source checks and execution audit passed"),
    ("ETF screening metadata","ready" if missing_screen.to_numpy().sum()==0 else "pending","Fill FactSet fields and measurement date"),
    ("Equity holdings look-through","ready" if holdings_ready else "pending","Full holdings, identifiers, sector and country needed"),
    ("Course risk-free origin","ready","File fingerprint recorded"),
    ("Exact risk-free conversion","ready" if reconstruction_match else "pending","Daily FRED data or professor preprocessing specification"),
    ("Drawdown tolerance","provisional",policy_inputs["drawdown_status"]),
    ("Discounted Sharpe","pending" if chosen_haircut is None else "provisional",policy_inputs["sharpe_haircut_status"]),
    ("Variants disclosure","ready","Includes retrospective choices and failed protocol attempt"),
    ("Final Bloomberg shares","pending","Use raw closes of 16 October 2026; current output is provisional")
],columns=["Item","Status","Action or evidence"])
display(readiness)
readiness.to_csv("exhibits/E19_report_readiness.csv",index=False)
''')
nb['cells'].extend(holdings_exhibits)
notebook.write_text(json.dumps(nb,ensure_ascii=False,indent=1),encoding='utf-8')
print('Section 12 and persistent input files prepared.')
