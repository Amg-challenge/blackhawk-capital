BlackHawk Capital - Asset Management Challenge 2026, Round 1
Code and data accompanying the report

Giorgio Galdiolo, Alessandro Maugeri, Stefano Martino, Giorgio Ferretto, Raffaele Sicolo
USI Lugano, Master in Finance

HOW TO RUN
  Keep every file in one folder and open SAA_Round1_analysis.ipynb. The notebook
  reads the CSVs from its own directory and runs top to bottom. The exhibits
  folder holds the figures and source tables it writes.

DATA CUTOFF
  Prices and estimates: 12 October 2026 information cutoff, returns through
  September 2026. The executed portfolio uses the closing prices of Friday
  16 October 2026.

FILES

Analysis
--------
  SAA_Round1_analysis.ipynb
    Main analysis. Loads the aligned return panels and the risk-free series,
    estimates volatilities and correlations, fits capped ERC and every
    comparison method, runs the in-sample and walk-forward backtests and the
    stress tests, and writes the exhibits.

Portfolio description
---------------------
  portfolio_for_PRTU.csv
    Portfolio description: the eight positions with shares, weights and the 16
    October 2026 closing prices entered in the Bloomberg portfolio.

Data preparation
----------------
  costruisci_csv.py
    Builds the aligned daily price panels from the original Excel exports.
  import_country_exports.py
    Parses the FactSet country exports into tidy CSV.
  import_equity_holdings.py
    Parses the FactSet holdings exports into tidy CSV.
  import_equity_overviews.py
    Parses the equity ETF overview PDFs into fund-level fields.
  import_remaining_overviews.py
    Same for the bond, gold and commodity ETF overviews.
  prepare_report_inputs.py
    Assembles the screening and composition inputs used by the report.
  use_team_risk_free.py
    Converts the FRED DGS1MO daily download into the monthly risk-free proxy.

Verification
------------
  audit_and_validate.py
    Re-checks the reported numbers against the source exports.
  verify_risk_free_source.py
    Verifies the risk-free series against its source file.

Data files
----------
  etf_adj_prices.csv
    Daily gross-total-return panel for the eight ETFs.
  etf_close_prices.csv
    Daily raw closing prices for the eight ETFs, used for share counts.
  rf_dgs1mo_daily.csv
    FRED DGS1MO daily download, the risk-free source.
  rf_team_monthly.csv
    Derived monthly risk-free proxy used in excess returns and Sharpe.
  rf_1m_tbill.csv
    The course risk-free series, retained for comparison only.
  candidates_adj_prices.csv
    Price panel for the candidate ninth ETFs that were tested.
  substitutes_adj_prices.csv
    Price panel for the substitution tests within sleeves.
  equity_holdings_inputs.csv
    Parsed holdings snapshots for the four equity ETFs.
  equity_holdings_residuals.csv
    Residual lines from the holdings parse, kept for traceability.
  equity_sector_inputs.csv
    Parsed sector snapshots for the equity sleeve.
  equity_country_inputs.csv
    Parsed country snapshots for the equity sleeve.
  equity_country_security_inputs.csv
    Security-level country attribution behind the look-through.
  equity_overview_inputs.csv
    Fund-level fields parsed from the equity ETF overviews.
  equity_overview_provenance.csv
    Field-level source references for the equity overviews.
  fund_overview_inputs.csv
    Fund-level fields for all eight ETFs: AUM, fees, spreads.
  fund_overview_provenance.csv
    Field-level source references for the eight overviews.
  etf_screening_inputs.csv
    Implementation screen inputs for the eight funds.
  screening_volume_history.csv
    Daily traded-volume history behind the capacity analysis.
  research_variants_register.csv
    The 34 documented configurations and protocol attempts.
  report_policy_inputs.json
    Explicit policy and source choices used by the report.

exhibits/
  65 files. The figures reproduced in the report and the source CSV behind each
  table and chart, named by exhibit number (E1, E3, E4, E9, E11 and so on).

NOT INCLUDED
  Report typesetting scripts and the course notebook template are left out: they
  produce the PDF and are not part of the analysis.
