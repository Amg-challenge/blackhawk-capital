"""Import FactSet overview PDFs without mixing segment and fund statistics."""
from pathlib import Path
import json
import re
import shutil
import uuid
import pandas as pd
import pymupdf

ROOT = Path(__file__).resolve().parent
EQUITY = ['VOO', 'VTV', 'IEFA', 'EEM']
destination = ROOT / 'factset_screening'
destination.mkdir(exist_ok=True)
screen = pd.read_csv(ROOT / 'etf_screening_inputs.csv', keep_default_na=False).set_index('Ticker')
screen = screen.rename(columns={'Median bid ask spread bps': 'Reported bid ask spread bps'})
holdings = pd.read_csv(ROOT / 'equity_holdings_inputs.csv')
records = []
provenance = []

def match(pattern, text):
    found = re.search(pattern, text)
    if not found:
        raise ValueError(f'Missing PDF field: {pattern}')
    return found.group(1).strip()

for ticker in EQUITY:
    file = destination / f'{ticker} Overview.pdf'
    incoming = Path.home() / 'Downloads' / file.name
    if incoming.exists():
        shutil.copy2(incoming, file)
    doc = pymupdf.open(file)
    assert ticker + '-USA' in doc[0].get_text(), f'Wrong instrument: {file}'
    text = doc[1].get_text()
    fund = text.split('Fund Statistics  As of:')[1].split('Distributions')[0]
    date = pd.to_datetime(match(r'^\s*([^\n]+)', fund)).strftime('%Y-%m-%d')
    aum_text = match(r'\nAUM\n([^\n]+)', fund)
    aum = re.fullmatch(r'\$([\d.]+)\s+(T|B|MM)', aum_text)
    assert aum, aum_text
    aum_billions = float(aum[1]) * {'T':1000, 'B':1, 'MM':.001}[aum[2]]
    expense = float(match(r'Expense Ratio Net\n([\d.]+)%', text))
    spread_text = match(r'Average Spread\n([^\n]+)', fund)
    spread = float(match(r'/\s*([\d.]+)%', spread_text)) * 100
    index = match(r'Underlying Index\n([\s\S]*?)\nBroad Based Index', text).replace('\n',' ')
    daily = ' '.join(match(r'Daily \$ / Share Trading Vol\.\n([\s\S]*?)\nAverage Spread', fund).split())
    source = f'FactSet; factset_screening/{file.name}; page 2; exported 2026-10-12'
    subset = holdings.loc[holdings['ETF'].eq(ticker)]
    count = subset['Holding identifier'].nunique()
    holdings_date = ', '.join(sorted(subset['Data date'].astype(str).unique()))
    values = {'Data date':date, 'Index tracked':index, 'AUM USD billions':aum_billions,
              'Expense ratio percent':expense, 'Reported bid ask spread bps':spread,
              'Spread statistic':'Average Spread',
              'Spread measurement period':'Not specified in source PDF',
              'Number of holdings':count, 'Holdings data date':holdings_date,
              'Source':source,
              'Notes':'AUM and daily trading volume are rounded in the overview. Holdings count includes equity securities only, from the separate full holdings export. Average-spread horizon is unspecified. CVol field definition remains unverified.'}
    for field,value in values.items():
        if field not in screen:
            screen[field] = ''
        screen.loc[ticker,field] = value
    records.append({'Ticker':ticker, 'Statistics date':date, 'AUM as reported':aum_text,
                    'AUM USD billions (rounded)':aum_billions, 'Net expense ratio percent':expense,
                    'Average spread bps':spread, 'Spread as reported':spread_text,
                    'Daily USD / share volume as reported':daily,
                    'ISIN':match(r'ISIN\n([^\n]+)',text), 'Index tracked':index,
                    'Equity securities in holdings export':count, 'Holdings data date':holdings_date,
                    'Spread horizon':'Not specified', 'Source':source})
    for field,raw in [('Fund AUM',aum_text),('Net expense ratio',f'{expense}%'),
                      ('Average Spread',spread_text),('Daily trading volume',daily),('Underlying index',index)]:
        provenance.append({'Ticker':ticker,'Field':field,'Source value':raw,
                           'Statistics date':date if field in ['Fund AUM','Daily trading volume','Average Spread'] else 'Not separately dated in PDF',
                           'Source':source})
    if ticker == 'VOO':
        doc[1].get_pixmap(matrix=pymupdf.Matrix(1.5,1.5)).save(str(destination/'VOO_overview_page2_check.png'))
    doc.close()

screen.fillna('').to_csv(ROOT/'etf_screening_inputs.csv',index=True)
pd.DataFrame(records).to_csv(ROOT/'equity_overview_inputs.csv',index=False)
pd.DataFrame(provenance).to_csv(ROOT/'equity_overview_provenance.csv',index=False)

# Keep the persistent section builder's schema consistent with the notebook.
builder = ROOT/'prepare_report_inputs.py'
source = builder.read_text(encoding='utf-8').replace('Median bid ask spread bps','Reported bid ask spread bps')
builder.write_text(source,encoding='utf-8')
path = ROOT/'SAA_Round1_analysis.ipynb'
nb = json.loads(path.read_text(encoding='utf-8'))
for cell in nb['cells']:
    s = ''.join(cell['source']).replace('Median bid ask spread bps','Reported bid ask spread bps')
    if s.startswith('### 12.1 ETF screening') and 'The four equity overview PDFs' not in s:
        s += '\nThe four equity overview PDFs provide fund AUM and trading statistics dated 9 October 2026 and net expense ratios. Report the source statistic as Average Spread; its measurement horizon is not specified. Fund AUM must be read from Fund Statistics, not Segment Details. Values are rounded, especially VOO AUM ($1 trillion). Separate holdings exports remain the source for composition; their observation dates differ. The PDF share-volume display alone does not establish the definition of the separate Price History CVol field.\n'
    cell['source'] = s.splitlines(True)
# Idempotent insertion; no duplicate exhibits on rerun.
nb['cells'] = [c for c in nb['cells'] if not c.get('metadata',{}).get('equity_overview_import')]
def cell(kind,text):
    result = {'cell_type':kind,'id':uuid.uuid4().hex[:8],
              'metadata':{'equity_overview_import':True},'source':text.splitlines(True)}
    if kind == 'code':
        result.update(execution_count=None,outputs=[])
    return result
markdown = '''### E25 — Equity ETF implementation: assets, fees and reported spreads
Read the four locally archived FactSet Overview PDFs. Fund and trading statistics are dated **9 October 2026**; the exports were generated on 12 October. Net expense ratios are undated within the overview. AUM is rounded: VOO's $1 trillion is not an exact valuation. The spread is the reported **Average Spread**, with an unspecified averaging period, not a verified 30-day median. Convert spread percentage to basis points by multiplying by 100 (0.004% = 0.4 bps).

The table includes the benchmark and the number of equity securities from the separate full holdings exports, with their own dates. Do not combine the overview's RBICS sectors or revenue-by-country statistics with the classifications already used in the holdings exhibits. The fee comparison is an implementation diagnostic: EEM's higher fee needs an explicit rationale against the already tested VWO alternative. Historical ETF returns already reflect ongoing fund expenses, so do not subtract these fees again. The weighted equity-fee contribution below covers these four funds only, not the full portfolio, and is not the transaction-cost assumption used in the backtest.

These files complete the available AUM, fee and reported-spread evidence for the equity sleeve. The spread horizon and CVol field definition remain source limitations; IEF, IGSB, GLD and DBC still need fund metadata. A single daily volume observation is neither average daily volume nor a market-impact estimate.
'''
code = '''equity_overviews = pd.read_csv("equity_overview_inputs.csv", keep_default_na=False).set_index("Ticker")
assert set(equity_overviews.index) == set(ASSETS[:4])
for column in ["AUM USD billions (rounded)", "Net expense ratio percent", "Average spread bps"]:
    equity_overviews[column] = pd.to_numeric(equity_overviews[column], errors="raise")
    assert (equity_overviews[column] > 0).all()
equity_overviews = equity_overviews.reindex(ASSETS[:4])
display(equity_overviews[["Statistics date", "AUM as reported", "Net expense ratio percent",
    "Average spread bps", "Index tracked", "Equity securities in holdings export", "Holdings data date",
    "Daily USD / share volume as reported", "Spread horizon"]])
equity_overviews.to_csv("exhibits/E25_equity_implementation_screen.csv")
equity_fee_contributions = pd.DataFrame({"Portfolio weight":W[SAA].reindex(equity_overviews.index),
    "Net expense ratio percent":equity_overviews["Net expense ratio percent"]})
equity_fee_contributions["Annual fee contribution to total portfolio (bps)"] = (
    equity_fee_contributions["Portfolio weight"] * equity_fee_contributions["Net expense ratio percent"] * 100)
display(equity_fee_contributions)
equity_fee_contributions.to_csv("exhibits/E25_equity_fee_contributions.csv")
print("Equity funds only: annual weighted fee contribution =",
      round(equity_fee_contributions["Annual fee contribution to total portfolio (bps)"].sum(),2), "bps of total portfolio.")
fig, axes = plt.subplots(1,2,figsize=(11,4))
for ax, column, title, ylabel in [
    (axes[0], "Net expense ratio percent", "Annual net fund expense ratio", "% per year"),
    (axes[1], "Average spread bps", "Reported average bid–ask spread", "Basis points; horizon unspecified")]:
    values = equity_overviews[column]
    values.plot.bar(ax=ax,color=["#305d87","#4e8298","#77a6a1","#bf8953"],rot=0)
    ax.set_title(title); ax.set_ylabel(ylabel); ax.set_xlabel("")
    ax.set_ylim(0,values.max()*1.22)
    for i,value in enumerate(values):
        ax.text(i,value,f"{value:g}",ha="center",va="bottom")
fig.suptitle("Equity ETF implementation — FactSet Overview exports")
fig.tight_layout()
fig.savefig("exhibits/E25_equity_fees_and_spreads.png",dpi=180,bbox_inches="tight")
plt.show()
'''
nb['cells'].extend([cell('markdown',markdown),cell('code',code)])
path.write_text(json.dumps(nb,ensure_ascii=False,indent=1),encoding='utf-8')
print(pd.DataFrame(records).to_string(index=False))
