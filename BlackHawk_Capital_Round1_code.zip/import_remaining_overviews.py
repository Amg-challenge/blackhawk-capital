"""Complete fund implementation inputs from the four non-equity PDFs."""
from pathlib import Path
import json
import re
import shutil
import uuid
import pandas as pd
import pymupdf

root = Path(__file__).resolve().parent
archive = root/'factset_screening'
screen = pd.read_csv(root/'etf_screening_inputs.csv',keep_default_na=False).set_index('Ticker')
rows = []
evidence = []
expected = {'IEF':'US4642874402','IGSB':'US4642886463','GLD':'US78463V1070','DBC':'US46138B1035'}
def field(pattern,text):
    m = re.search(pattern,text)
    if not m:
        raise ValueError(f'Missing field: {pattern}')
    return ' '.join(m[1].split())

for ticker,isin in expected.items():
    filename = 'IEF Oveeriew.pdf' if ticker == 'IEF' else f'{ticker} Overview.pdf'
    target = archive/filename
    original = Path.home()/'Downloads'/filename
    if original.exists():
        shutil.copy2(original,target)
    doc = pymupdf.open(target)
    text = doc[1].get_text()
    assert field(r'ISIN\n([^\n]+)',text) == isin
    assert ticker+'-USA' in text
    fund = text.split('Fund Statistics  As of:')[1]
    date = pd.to_datetime(field(r'^\s*([^\n]+)',fund)).strftime('%Y-%m-%d')
    aum_raw = field(r'\nAUM\n([^\n]+)',fund)
    aum_match = re.fullmatch(r'\$([\d.]+)\s+(T|B|MM)',aum_raw)
    assert aum_match
    aum = float(aum_match[1])*{'T':1000,'B':1,'MM':.001}[aum_match[2]]
    fee = float(field(r'Expense Ratio Net\n([\d.]+)%',text))
    spread_raw = field(r'Average Spread\n([^\n]+)',text)
    spread = float(field(r'/\s*([\d.]+)%',spread_raw))*100
    daily = field(r'Daily \$ / Share Trading Vol\.\n([\s\S]*?)\nAverage Spread',text)
    index = field(r'Underlying Index\n([\s\S]*?)\nBroad Based Index',text)
    source = f'FactSet; factset_screening/{filename}; page 2; exported 2026-10-12'
    values = {'Data date':date,'Index tracked':index,'AUM USD billions':aum,
        'Expense ratio percent':fee,'Reported bid ask spread bps':spread,
        'Spread statistic':'Average Spread','Spread measurement period':'Not specified in source PDF',
        'Source':source,'Notes':'Fund statistics only; rounded AUM and daily volume. Spread horizon and Price History CVol definition are unverified. Holdings count not supplied by the overview; not inferred from other statistics.'}
    for key,value in values.items():
        screen.loc[ticker,key] = value
    rows.append({'Ticker':ticker,'Statistics date':date,'AUM as reported':aum_raw,
        'AUM USD billions (rounded)':aum,'Net expense ratio percent':fee,
        'Average spread bps':spread,'Spread as reported':spread_raw,
        'Daily USD / share volume as reported':daily,'ISIN':isin,'Index tracked':index,
        'Spread horizon':'Not specified','Source':source})
    for key,value in [('Fund AUM',aum_raw),('Net expense ratio',f'{fee}%'),('Average Spread',spread_raw),
                       ('Daily trading volume',daily),('Underlying index',index)]:
        evidence.append({'Ticker':ticker,'Field':key,'Source value':value,
            'Statistics date':date if key in ['Fund AUM','Average Spread','Daily trading volume'] else 'Not separately dated in PDF',
            'Source':source})
    doc[1].get_pixmap(matrix=pymupdf.Matrix(1.2,1.2)).save(str(archive/f'{ticker}_overview_page2_check.png'))
    doc.close()

screen.to_csv(root/'etf_screening_inputs.csv')
equity = pd.read_csv(root/'equity_overview_inputs.csv',keep_default_na=False)
all_funds = pd.concat([equity,pd.DataFrame(rows)],ignore_index=True).set_index('Ticker').reindex(screen.index)
all_funds.fillna('').to_csv(root/'fund_overview_inputs.csv')
equity_evidence = pd.read_csv(root/'equity_overview_provenance.csv',keep_default_na=False)
pd.concat([equity_evidence,pd.DataFrame(evidence)],ignore_index=True).to_csv(root/'fund_overview_provenance.csv',index=False)

path = root/'SAA_Round1_analysis.ipynb'
nb = json.loads(path.read_text(encoding='utf-8'))
nb['cells'] = [c for c in nb['cells'] if not c.get('metadata',{}).get('full_overview_import')]
for cell in nb['cells']:
    s = ''.join(cell['source'])
    s = s.replace('IEF, IGSB, GLD and DBC still need fund metadata.',
        'Fund metadata for IEF, IGSB, GLD and DBC is now included in E26 below; their holdings counts are not supplied by these PDFs.')
    cell['source'] = s.splitlines(True)
def add(kind,s):
    cell = {'cell_type':kind,'id':uuid.uuid4().hex[:8],
        'metadata':{'full_overview_import':True},'source':s.splitlines(True)}
    if kind == 'code':
        cell.update(execution_count=None,outputs=[])
    nb['cells'].append(cell)
add('markdown','''### E26 — Complete eight-fund implementation screen
All eight FactSet Overview PDFs are archived locally. Fund AUM and trading statistics share the observation date **9 October 2026**. Display the rounded AUM as reported, annual net expense ratio and reported Average Spread. Expense ratios are not separately dated in the source. The spread averaging horizon is unspecified; it is not a 30-day median. Source values, dates and page references are retained in `fund_overview_provenance.csv`. Fund Statistics AUM is distinct from aggregate Segment Details AUM.

Combine current allocation weights with current net expense ratios to calculate the annual portfolio-weighted expense ratio. This is a current implementation estimate, not the expense ratio throughout the historical sample. It is already reflected in fund returns and must not be deducted again. Spreads, annual fees and the backtest's transaction-cost assumption measure different things.

The PDFs supply rounded **one-day** USD and share trading volumes. Position / reported daily USD volume provides a one-day capacity snapshot, not average daily volume, execution time or a market-impact estimate. The existing 60-session CVol diagnostics remain conditional until the Price History field definition is confirmed. ETF secondary-market volume alone does not capture primary-market creation/redemption capacity.

For interpretation, IEF provides Treasury exposure with effective duration 6.8 years; IGSB provides corporate credit with duration 2.7 years (both reported as of 31 August 2026). GLD holds physical bullion; DBC uses futures and a roll strategy. DBC's generic 'Holds Derivatives: No' flag conflicts with its explicit futures strategy, so the flag is not used to classify economic exposure. The overviews do not provide a verified holding count for these four funds. AUM, fee and reported-spread coverage is now complete for all eight funds; source limitations and remaining composition inputs are still disclosed rather than marked resolved.
''')
add('code','''fund_overviews = pd.read_csv("fund_overview_inputs.csv", keep_default_na=False).set_index("Ticker").reindex(ASSETS)
assert fund_overviews.index.is_unique and fund_overviews["ISIN"].ne("").all()
assert fund_overviews["Statistics date"].eq("2026-10-09").all()
for column in ["AUM USD billions (rounded)","Net expense ratio percent","Average spread bps"]:
    fund_overviews[column] = pd.to_numeric(fund_overviews[column],errors="raise")
    assert (fund_overviews[column] > 0).all()
fund_overviews["Portfolio weight"] = W[SAA].reindex(ASSETS)
fund_overviews["Annual weighted fee contribution (bps)"] = (
    fund_overviews["Portfolio weight"] * fund_overviews["Net expense ratio percent"] * 100)
def reported_usd_volume(value):
    amount, unit = value.split("/")[0].strip().replace("$","").split()
    return float(amount) * {"T":1e12,"B":1e9,"MM":1e6,"K":1e3}[unit]
fund_overviews["Reported one-day USD volume (rounded)"] = fund_overviews["Daily USD / share volume as reported"].map(reported_usd_volume)
fund_overviews["Position / reported one-day USD volume"] = (
    fund_overviews["Portfolio weight"] * CAPITAL / fund_overviews["Reported one-day USD volume (rounded)"])
display(fund_overviews[["AUM as reported","Net expense ratio percent","Average spread bps",
    "Portfolio weight","Annual weighted fee contribution (bps)","Daily USD / share volume as reported",
    "Position / reported one-day USD volume","Index tracked"]])
fund_overviews.to_csv("exhibits/E26_complete_fund_screen.csv")
total_fee_bps = fund_overviews["Annual weighted fee contribution (bps)"].sum()
print(f"Current annual portfolio-weighted net expense ratio: {total_fee_bps:.2f} bps = {total_fee_bps/100:.4f}%. Already reflected in ETF returns.")
fig, axes = plt.subplots(1,3,figsize=(15,4))
for ax,column,title,label in [
    (axes[0],"Net expense ratio percent","Annual net expense ratios","% per year"),
    (axes[1],"Average spread bps","Reported average spreads","bps; horizon unspecified"),
    (axes[2],"Annual weighted fee contribution (bps)","Contribution to portfolio fees","bps per year")]:
    values = fund_overviews[column]
    values.plot.bar(ax=ax,rot=45,color="#427c92")
    ax.set_title(title); ax.set_ylabel(label); ax.set_xlabel(""); ax.set_ylim(0,values.max()*1.2)
fig.suptitle("Eight-fund implementation — FactSet Overview exports")
fig.tight_layout()
fig.savefig("exhibits/E26_complete_fund_costs_and_spreads.png",dpi=180,bbox_inches="tight")
plt.show()
''')
path.write_text(json.dumps(nb,ensure_ascii=False,indent=1),encoding='utf-8')
print(pd.DataFrame(rows).to_string(index=False))
