"""Verify course monthly risk-free against the supplied daily FRED export."""
from pathlib import Path
import hashlib
import json
import shutil
import pandas as pd

root = Path(__file__).resolve().parent
incoming = Path.home()/'Downloads'/'rf_dgs1mo_daily.csv.csv'
target = root/'rf_dgs1mo_daily.csv'
if incoming.exists():
    shutil.copy2(incoming,target)
daily = pd.read_csv(target,index_col=0,parse_dates=True)
assert daily.columns.tolist() == ['DGS1MO']
assert daily.index.is_unique and daily.index.is_monotonic_increasing
assert str(daily.index.min().date()) == '2012-10-01'
assert str(daily.index.max().date()) == '2026-09-30'
yields = pd.to_numeric(daily['DGS1MO'],errors='raise').dropna()
monthly = yields.resample('ME').mean()/1200
course = pd.read_csv(root/'rf_1m_tbill.csv',index_col=0,parse_dates=True)['DGS1MO']
comparison = pd.concat([course.rename('Course monthly decimal'),monthly.rename('Daily mean / 1200')],axis=1).loc[monthly.index]
assert comparison.notna().all().all()
comparison['Difference'] = comparison.iloc[:,0]-comparison.iloc[:,1]
assert comparison['Difference'].abs().max() < 1e-12
comparison.to_csv(root/'exhibits/E17_all_available_months_reconstruction.csv')
policy_path = root/'report_policy_inputs.json'
policy = json.loads(policy_path.read_text(encoding='utf-8'))
policy.update(risk_free_conversion_verified=True,
    risk_free_monthly_conversion='Verified numerically: arithmetic mean of available daily annual yields within each calendar month / 100 / 12. Missing daily observations excluded, not filled. All 168 overlapping complete months agree within 1e-12.',
    risk_free_daily_source='User-downloaded FRED DGS1MO CSV; 2012-10-01 through 2026-09-30; annual percent; verified 2026-10-12',
    risk_free_daily_file_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
    risk_free_verification_max_difference=float(comparison['Difference'].abs().max()),
    price_field_confirmation='User confirmed on 2026-10-12: FactSet Gross Total Return includes dividend reinvestment and Price is raw closing price. Provider field help not archived.',
    screening_notes='Price History CVol is assumed to represent consolidated daily shares; exact field definition remains unverified. Price times CVol capacity figures are conditional. ETF expenses already reflected in returns.')
policy_path.write_text(json.dumps(policy,indent=2),encoding='utf-8')

nb_path = root/'SAA_Round1_analysis.ipynb'
nb = json.loads(nb_path.read_text(encoding='utf-8'))
for c in nb['cells']:
    s = ''.join(c['source'])
    if s.startswith('### 12.2 Risk-free provenance'):
        s = '''### 12.2 Risk-free provenance and verified monthly reconstruction
The original course file remains unchanged. The newly archived FRED daily DGS1MO export contains annualized yields in percent from 1 October 2012 through 30 September 2026. Compute the arithmetic mean of available observations in each calendar month, excluding missing observations, then divide by 100 and by 12 to obtain a monthly decimal yield proxy.

This reconstruction matches the course file in all 168 overlapping complete months to numerical precision (maximum absolute difference below 1e-12). The cell also verifies coverage and agreement for every month actually used by the backtest. This confirms the numerical conversion for the available history; it is not evidence that the series is a realized Treasury-bill total-return index. It is a one-month constant-maturity Treasury yield proxy. The course file's partial October observation is not used in complete-month analysis. Both input files and their fingerprints are retained.
'''
    elif s.startswith('### 12.1 ETF screening'):
        if 'User confirmation on 12 October' not in s:
            s += '\nUser confirmation on 12 October 2026: Gross Total Return includes reinvested dividends and Price is the raw closing price. This is user-confirmed metadata, not an archived provider field definition. CVol is interpreted provisionally as consolidated daily share volume; all Price × CVol liquidity statistics remain conditional on that assumption. No CVol-based conclusion affects the optimized SAA or its performance calculations.\n'
    elif s.startswith('rf_file = Path'):
        s = s.replace('daily = pd.read_csv("rf_dgs1mo_daily.csv",index_col=0,parse_dates=True)',
            'daily_source = Path("rf_dgs1mo_daily.csv")\n    assert hashlib.sha256(daily_source.read_bytes()).hexdigest() == policy_inputs["risk_free_daily_file_sha256"], "Daily risk-free source changed"\n    daily = pd.read_csv(daily_source,index_col=0,parse_dates=True)\n    assert daily.index.is_unique and daily.index.is_monotonic_increasing')
        s = s.replace('print("Numerical agreement with daily-mean convention:",reconstruction_match)',
            'assert reconstruction_match, "Risk-free reconstruction no longer matches course monthly data"\n    print("Verified monthly conversion: mean available daily annual percent / 1200.")\n    print("Numerical agreement for all backtest months:",reconstruction_match)')
    elif 'register = pd.read_csv' in s:
        s = s.replace('"Unmodified course monthly DGS1MO file; exact conversion pending reconstruction"',
            '"Unmodified course monthly DGS1MO file; daily-mean / 1200 conversion verified against FRED"')
        s = s.replace('"Daily FRED data or professor preprocessing specification"',
            '"Archived daily FRED export; monthly mean / 1200 agrees with course file"')
        s = s.replace('"rf_1m_tbill.csv":"Unmodified',
            '"rf_dgs1mo_daily.csv":"FRED daily annual-percent source; archived reconstruction evidence",\n    "rf_1m_tbill.csv":"Unmodified')
    c['source'] = s.splitlines(True)
nb_path.write_text(json.dumps(nb,ensure_ascii=False,indent=1),encoding='utf-8')
print('Verified',len(comparison),'months. Maximum difference:',comparison['Difference'].abs().max())
print('Available daily observations:',len(yields),'Missing rows:',daily['DGS1MO'].isna().sum())
